from flask import Flask, request, jsonify
import numpy as np
import pandas as pd
from keras.models import load_model

app = Flask(__name__)

# Memuat model
model = load_model('collaborative_filtering.h5')

df = pd.read_csv('https://raw.githubusercontent.com/fadhlyal/data-set/main/data_clean.csv')

@app.route("/")
def hello():
    """Return a friendly HTTP greeting.
    Returns:
        A string with the words 'Server Berjalan!'.
    """
    return "Server Berjalan!"

@app.route('/recommend', methods=['POST'])
def recommend():
    # Menerima input dari Postman
    category_data = np.array(request.json['category_data'])
    id_user = 948
    
    # Membuat array user
    user = np.array([id_user for i in range(len(category_data))])
    
    # Melakukan prediksi menggunakan model
    predictions = model.predict([user, category_data])
    predictions = np.array([a[0] for a in predictions])
    
    # Mengurutkan dan memilih 10 kategori dengan prediksi tertinggi
    recommended_category_ids = (-predictions).argsort()[:10]
    
    # Membuat dataframe rekomendasi
    recommendation = pd.DataFrame()
    i = 0
    while True:
        recommendation = df[df["category"] == recommended_category_ids[i]].sort_values(by=['viewCount'], ascending=False).head()
        if len(recommendation) == 0:
            if len(recommended_category_ids) <= 1:
                recommendation= "Video Terlalu Sedikit"
                break
            i += 1
        else:
            break
    
    data = []
    for i in range((recommendation.shape)[0]) :
        tmp_dict = {}
        tmp_dict["judul"] = str(recommendation["vidTitle"].iloc[i])
        tmp_dict["channel"] = str(recommendation["chanName"].iloc[i])
        tmp_dict["subs"] = int(recommendation["subsCount"].iloc[i])
        tmp_dict["link"] = str(recommendation["vidUrl"].iloc[i])
        tmp_dict["view"] = int(recommendation["viewCount"].iloc[i])
        tmp_dict["like"] = int(recommendation["likeCount"].iloc[i])
        data.append(tmp_dict)

    # Mengembalikan hasil rekomendasi sebagai response
    return jsonify({'data': data})

if __name__ == '__main__':
    app.run(host="127.0.0.1", port=8080, debug=True)
